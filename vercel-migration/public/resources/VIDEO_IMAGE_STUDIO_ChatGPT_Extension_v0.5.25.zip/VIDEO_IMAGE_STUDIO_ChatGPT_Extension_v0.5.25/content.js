(() => {
  // One bridge per extension version: after a self-update the new version injects itself again.
  const bridgeKey = '__VIS_CHAT_BRIDGE_' + (chrome.runtime.getManifest?.()?.version||'dev').replace(/\W/g, '_');
  if (window[bridgeKey]) return;
  window[bridgeKey] = true;
  let currentJobId = '';
  let lastDomChange = Date.now();
  new MutationObserver(() => { lastDomChange = Date.now(); }).observe(document.documentElement, {subtree:true, childList:true, characterData:true});
  let currentJobType = '';
  let cancelled = false;
  let generation = 0;
  let replyContext = {};
  const finished = new Set();
  const downloads=new Set();

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const composer = () => document.querySelector('#prompt-textarea') || document.querySelector('div[contenteditable="true"][data-virtualkeyboard="true"]') || document.querySelector('div[contenteditable="true"].ProseMirror');
  // Current ChatGPT labels the composer's stop control just "Stop" without a test id.
  const buttonLabel = button => (button.getAttribute('aria-label') || button.textContent || '').trim();
  const stopButton = () => document.querySelector('button[data-testid="stop-button"]')
    || [...(composer()?.closest('form')?.querySelectorAll('button') || [])].find(button => /^(stop|stop generating|stop streaming|stop answering|dừng|dừng tạo|dừng tạo câu trả lời|dừng trả lời)$/i.test(buttonLabel(button)))
    || [...document.querySelectorAll('button')].find(button => /^(stop generating|stop streaming|stop answering|dừng tạo|dừng tạo câu trả lời|dừng trả lời)$/i.test(buttonLabel(button)));
  const isVisible = node => {
    if (!node) return false;
    const style = window.getComputedStyle(node);
    const rect = node.getBoundingClientRect();
    return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
  };
  const sendButton = node => {
    const form = node?.closest('form');
    const selector = "button[data-testid='send-button'], button[aria-label*='Send'], button[aria-label*='send'], button[aria-label*='Gửi'], button[aria-label*='gửi'], button[title*='Send'], button[title*='Gửi'], form button[type='submit']";
    const buttons = [...(form?.querySelectorAll("button[type='submit'], button[data-testid='send-button']") || []), ...document.querySelectorAll(selector)];
    return buttons.find(button => !button.disabled && isVisible(button));
  };
  const jsonFromPage = kind => VISReplyReader.read(document, { ...replyContext, type: kind }).text;
  const assistantText = kind => {
    const structured = jsonFromPage(kind);
    if (structured) return structured;
    return (VISReplyReader.sources(document, replyContext).sources.at(-1) || '').trim();
  };
  const emit = payload => chrome.runtime.sendMessage({ type: 'vis-chat-event', payload }).catch(() => null);

  // Checked every 500 ms while ChatGPT streams: no getComputedStyle/layout here (that alone is costly on
  // a long animated answer). The stop control only exists while ChatGPT is answering.
  const isGenerating = () => {
    const button = stopButton();
    return Boolean(button && !button.disabled && !button.closest('[hidden], [aria-hidden="true"]')) || creatingImage();
  };
  // While ChatGPT draws a picture it shows "Creating image" without a stop control: that is still work in progress,
  // otherwise the watchdog sees an idle tab after 2 minutes and reloads it, losing the picture.
  const creatingImage = () => {
    const turns = document.querySelectorAll('[data-message-author-role="assistant"]');
    const last = turns[turns.length - 1];
    if (!last) return false;
    const turn = last.closest('article') || last;
    if (!/creating image|generating image|đang tạo (hình )?ảnh/i.test((turn.innerText || '').slice(0, 400))) return false;
    return !Array.from(turn.querySelectorAll?.('img') || []).some(image => image.complete && image.naturalWidth >= 256 && image.naturalHeight >= 256);
  };

  const activeImageMode = () => {
    const box = composer();
    const root = box?.closest('form') || box?.parentElement?.parentElement;
    return [...(root?.querySelectorAll('button') || [])].filter(isVisible).find(button => /^(create image|creating image|image|images|tạo ảnh|tạo hình ảnh)$/i.test((button.innerText || '').trim()));
  };
  async function clearImageMode() {
    const chip = activeImageMode();
    if (!chip) return;
    const remove = chip.parentElement?.querySelector('button[aria-label*="Remove"], button[aria-label*="remove"], button[aria-label*="Close"], button[aria-label*="Xóa"], button[aria-label*="Đóng"]');
    if (remove) remove.click();
    await sleep(300);
    if (activeImageMode()) throw new Error('ChatGPT đang bật chế độ Tạo ảnh. Hãy tắt Tạo ảnh cạnh ô nhập rồi phân tích lại phần này. Lệnh phân tích chưa được gửi.');
  }

  // A text job must never produce a picture. ChatGPT sometimes picks its image tool anyway (scene prompts talk
  // about images), so a picture after this job's prompt means it drew instead.
  const IMAGE_TOOL_TEXT = /creating image|generating image|đang tạo (hình )?ảnh/i;
  // Pictures after the newest prompt carrying this job's marker (older pictures in the chat never count).
  const pictureNodesAfterPrompt = (context = replyContext) => {
    const marker = '[VIS_JOB_ID:' + (context?.id || '') + ']';
    const users = [...document.querySelectorAll('[data-message-author-role="user"], [data-turn="user"]')];
    const prompt = users.filter(node => (node.textContent || '').includes(marker)).at(-1);
    if (!prompt) return [];
    // Only pictures between this prompt and the next user message: another job's picture never counts.
    const next = users.find(node => node !== prompt && (prompt.compareDocumentPosition(node) & 4) && !prompt.contains(node));
    return [...document.querySelectorAll('main img')].filter(image => (!next || (next.compareDocumentPosition(image) & 2)) && !image.closest('form') && (prompt.compareDocumentPosition(image) & 4) && !prompt.contains(image) && (/generated image|hình ảnh đã tạo|ảnh đã tạo/i.test(image.alt || '') || image.naturalWidth >= 256 || Number(image.getAttribute('width')) >= 256));
  };
  const picturesAfterPrompt = () => pictureNodesAfterPrompt().length;
  const IMAGE_INSTEAD = 'VIS_IMAGE_INSTEAD';
  const drewImage = () => picturesAfterPrompt() > 0 || VISReplyReader.light(() => VISReplyReader.sources(document, replyContext).sources.some(text => IMAGE_TOOL_TEXT.test(text)));
  async function stopAndSettle() {
    stopButton()?.click();
    for (let i = 0; i < 40 && isGenerating(); i += 1) await sleep(500);
    await sleep(1500);
  }
  const finishedUrls = images => images.filter(image => image.complete && image.naturalWidth >= 256 && image.naturalHeight >= 256).map(image => image.currentSrc || image.src || '').filter(url => /^(https?:|blob:)/.test(url));
  // ChatGPT sometimes shows a picture-only reply with no answer block ("no-new-answer"): the pictures between this
  // job's prompt and the next message are still this job's, so they are read directly instead of nudging again.
  const imageUrls = (context = replyContext) => {
    const fromReply = finishedUrls([...(VISReplyReader.sources(document, context).node?.querySelectorAll('img') || [])]);
    return fromReply.length ? fromReply : finishedUrls(pictureNodesAfterPrompt(context));
  };
  // In a background tab Edge does not load a lazy picture until it is scrolled into view, so a finished picture
  // stayed "not complete" and the job waited until it timed out (seen 15-16/11: the picture loaded the moment the
  // user opened the tab). Ask the newest picture of this job to load now and give it a few seconds.
  const pictureLoaded = image => image.complete && image.naturalWidth >= 256 && image.naturalHeight >= 256;
  async function loadPictures(context = replyContext) {
    const last = pictureNodesAfterPrompt(context).at(-1);
    if (!last || pictureLoaded(last)) return last || null;
    try { last.loading = 'eager'; last.scrollIntoView?.({ block: 'center' }); } catch {}
    for (let i = 0; i < 20 && !pictureLoaded(last); i += 1) await sleep(300);
    return last;
  }
  // Once ChatGPT has finished (never while it is drawing, when a picture can be a blurred preview), a picture that
  // still has not rendered is read from its own address: the file on ChatGPT's server is the finished picture.
  const unrenderedUrl = image => image && !pictureLoaded(image) && !isGenerating() ? String(image.currentSrc || image.src || '').match(/^(https?:|blob:)\S+/)?.[0] || '' : '';
  const expandedImagePrompts = new WeakSet();
  async function expandImagePrompts(context) {
    // Long ChatGPT prompts can contain only the preview until Show more is clicked.
    // Expand the user turn, then keep using exact prompt matching (never a style prefix).
    let expanded = false;
    const known = VISReplyReader.turns(document, context).filter(turn => turn.role === 'user').flatMap(turn => [...turn.node.querySelectorAll('button, [role="button"]')]);
    const controls = [...new Set([...known, ...document.querySelectorAll('button, [role="button"]')])];
    for (const button of controls) {
        if (button.closest?.('form, #prompt-textarea, [contenteditable="true"]')) continue;
        const label = (button.innerText || button.textContent || button.getAttribute('aria-label') || '').trim();
        if (!/^(show more|read more|see more|xem thêm|hiển thị thêm|mở rộng)$/i.test(label) || expandedImagePrompts.has(button)) continue;
        expandedImagePrompts.add(button);button.click();expanded = true;
    }
    if (expanded) await sleep(150);
  }
  // ChatGPT sometimes shows "Which image/response do you like more?" with two results and blocks the
  // composer until one is chosen. Choose the first option (consistent, no judgement), then read the result.
  const PREFER_FIRST = /^(image 1 is better|response 1 is better|i prefer (image|response) 1|ảnh 1 tốt hơn|phản hồi 1 tốt hơn|câu trả lời 1 tốt hơn)$/i;
  async function resolveComparison() {
    const button = [...document.querySelectorAll('button, [role="button"]')].find(item => PREFER_FIRST.test((item.innerText || item.textContent || item.getAttribute('aria-label') || '').trim()));
    if (!button) return false;
    button.click();
    await sleep(1500);
    return true;
  }
  async function imagePayload(context) {
    await resolveComparison();
    await expandImagePrompts(context);
    const lastPicture = await loadPictures(context);
    const imageUrl = imageUrls(context).at(-1) || unrenderedUrl(lastPicture);
    if (!imageUrl) throw new Error('Chưa tìm thấy ảnh hoàn tất đúng lệnh của cảnh này. Mở đúng hội thoại và cuộn tới ảnh. [' + VISReplyReader.sources(document, context).reason + ']');
    const controller=new AbortController();downloads.add(controller);
    try{
    try {
      const response = await fetch(imageUrl, { credentials: 'include',signal:controller.signal });
      if (!response.ok) throw new Error('HTTP ' + response.status);
      const blob = await response.blob();
      if (blob.size > 8388608) throw new Error('Ảnh vượt giới hạn 8 MB.');
      const bytes = new Uint8Array(await blob.arrayBuffer());
      const mime = bytes[0] === 137 && bytes[1] === 80 && bytes[2] === 78 && bytes[3] === 71 ? 'image/png' : bytes[0] === 255 && bytes[1] === 216 ? 'image/jpeg' : bytes[0] === 82 && bytes[1] === 73 && bytes[2] === 70 && bytes[3] === 70 && bytes[8] === 87 && bytes[9] === 69 && bytes[10] === 66 && bytes[11] === 80 ? 'image/webp' : '';
      if (!mime) throw new Error('Tệp nhận được không phải PNG/JPEG/WebP.');
      let binary = '';
      for (let i = 0; i < bytes.length; i += 32768) binary += String.fromCharCode(...bytes.subarray(i, i + 32768));
      return { jobId: context.id, state: 'completed', imageDataUrl: 'data:' + mime + ';base64,' + btoa(binary) };
    } catch (error) {
      if(controller.signal.aborted)throw new Error('Đã dừng tải ảnh.');
      // Displaying a signed cross-origin image does not grant page fetch permission.
      // The extension worker has narrowly scoped host permissions for this fallback.
      if (!/^https:\/\//.test(imageUrl)) throw error;
      const result = await chrome.runtime.sendMessage({type:'vis-fetch-image',url:imageUrl});
      if (!result?.ok || !result.imageDataUrl) throw new Error('Chưa tải được tệp ảnh: ' + (result?.error || error?.message || String(error)));
      return {jobId:context.id,state:'completed',imageDataUrl:result.imageDataUrl};
    }
    }finally{downloads.delete(controller);}
  }

  // Seen on the user's Plus account: ChatGPT accepted the long image prompt and then did nothing (no
  // reply, no "Creating image") until the user typed "Tạo ảnh cho tôi". When ChatGPT stays idle without an
  // image, send that short nudge ourselves, tagged with this job's marker so the image is still matched
  // to this scene. At most two nudges; then the normal timeout reports the error.
  const NUDGE_AFTER_MS = 45000, MAX_NUDGES = 2;
  const nudgeText = id => '[VIS_JOB_ID:' + id + '] Tạo ảnh theo đúng mô tả ở tin nhắn trên ngay bây giờ bằng công cụ tạo ảnh. Chỉ trả về một ảnh, không giải thích.';
  async function waitForImage(_before, token) {
    const deadline = Date.now() + 10 * 60 * 1000;
    let lastSentAt = Date.now(), nudges = 0, busyAt = Date.now();
    while (Date.now() < deadline) {
      if (cancelled || token !== generation) throw new Error('Đã dừng tác vụ tạo ảnh.');
      await expandImagePrompts(replyContext);
      if (cancelled || token !== generation) throw new Error('Đã dừng tác vụ tạo ảnh.');
      const busy = isGenerating();
      if (busy) busyAt = Date.now();
      if (!busy && await resolveComparison()) continue;
      if (!busy && !imageUrls().length && pictureNodesAfterPrompt().length) {
        await loadPictures();
        // Still not rendered 10 s after ChatGPT stopped: read it from its address instead of waiting for the timeout.
        if (!imageUrls().length && !isGenerating() && Date.now() - busyAt >= 10000) return imagePayload(replyContext);
      }
      if (imageUrls().length && !busy) return imagePayload(replyContext);
      if (!busy && nudges < MAX_NUDGES && Date.now() - lastSentAt >= NUDGE_AFTER_MS && Date.now() - busyAt >= NUDGE_AFTER_MS && !imageUrls().length) {
        nudges += 1;
        await fillComposer(nudgeText(replyContext.id));
        if (cancelled || token !== generation) throw new Error('Đã dừng tác vụ tạo ảnh.');
        await submit(token);
        lastSentAt = Date.now(); busyAt = Date.now();
        await emit({ jobId: replyContext.id, state: 'sent', nudge: nudges });
      }
      await sleep(1500);
    }
    throw new Error('ChatGPT quá thời gian tạo ảnh hoặc không đọc được ảnh đúng cảnh.');
  }

  async function waitForFinalAnswer(before, kind, token) {
    // Reading the reply scans the DOM and parses JSON; doing that on every streamed token froze the
    // ChatGPT tab mid-answer. The observer only records when the page last changed; reading is
    // throttled: progress every 4 s while ChatGPT writes, the final reply once it has been idle 3 s.
    let last = assistantText(kind);
    let started = Boolean(last && last !== before);
    let changedAt = Date.now(), domChangedAt = Date.now();
    let sentScenes = 0, progressAt = 0, checkedAt = 0, progressGap = 5000;
    const observer = new MutationObserver(() => { domChangedAt = Date.now(); });
    observer.observe(document.body, { subtree: true, childList: true, characterData: true });
    const deadline = Date.now() + 10 * 60 * 1000;
    try {
      while (Date.now() < deadline) {
        if (cancelled || token !== generation) throw new Error('Đã dừng tác vụ.');
        const generating = isGenerating();
        if (generating) { started = true; changedAt = Math.max(changedAt, domChangedAt); }
        if (Date.now() - progressAt >= progressGap) {
          // Self-pacing: the next progress read waits at least 10x the time this one took, so the
          // extension never occupies more than ~10% of the page's main thread while ChatGPT writes.
          const readStart = Date.now();
          if (kind !== 'image_generation' && drewImage()) throw new Error(IMAGE_INSTEAD);
          let progress = null;
          if (kind === 'part_analysis') progress = VISReplyReader.light(() => VISReplyReader.readStreaming(document, { ...replyContext, type: kind }));
          const cost = Date.now() - readStart;
          progressAt = Date.now(); progressGap = Math.max(5000, cost * 10);
          if (progress) {
            if (progress.text) {
              const count = JSON.parse(progress.text).scenes.length;
              if (count > sentScenes) { await emit({ jobId: replyContext.id, state: 'progress', text: progress.text }); sentScenes = count; }
            }
          }
        }
        if (!generating && Date.now() - domChangedAt >= 3000 && Date.now() - checkedAt >= 2000) {
          checkedAt = Date.now();
          const next = assistantText(kind);
          if (next !== last) { last = next; changedAt = Date.now(); }
          if (next && next !== before) started = true;
          if (await resolveComparison()) { changedAt = Date.now(); continue; }
          if (started && last && Date.now() - changedAt >= 3000) {
            if (kind !== 'image_generation' && drewImage()) throw new Error(IMAGE_INSTEAD);
            const result = VISReplyReader.read(document, { ...replyContext, type: kind });
            if (result.text) return result.text;
            // ChatGPT finished and stayed idle, but the reply for THIS job is not valid JSON: fail clearly instead of hanging.
            if (result.reason === 'invalid-json' && Date.now() - changedAt >= 45000) throw new Error('ChatGPT đã trả lời xong nhưng JSON không hợp lệ (' + result.detail + '). Kiểm tra hội thoại rồi bấm Đồng bộ kết quả ngay hoặc chạy lại phần này.');
          }
        }
        await sleep(500);
      }
      throw new Error('ChatGPT quá thời gian phản hồi.');
    } finally { observer.disconnect(); }
  }

  async function waitForComposer() {
    for (let i = 0; i < 40; i += 1) {
      const node = composer();
      if (node) return node;
      await sleep(250);
    }
    throw new Error('Không tìm thấy ô nhập ChatGPT. Hãy F5 tab ChatGPT.');
  }

  async function fillComposer(text) {
    const node = await waitForComposer();
    node.focus();
    if (node instanceof HTMLTextAreaElement || node instanceof HTMLInputElement) {
      const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(node), 'value')?.set;
      setter?.call(node, text);
      node.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
      const range = document.createRange();
      range.selectNodeContents(node);
      const selection = window.getSelection();
      selection.removeAllRanges();
      selection.addRange(range);
      document.execCommand('insertText', false, text);
      if ((node.innerText || '').trim() !== text.trim()) {
        node.textContent = text;
        node.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
      }
    }
    await sleep(300);
  }

  const draftText = node => {
    if (!node) return '';
    const text = typeof node.value === 'string' ? node.value : typeof node.innerText === 'string' ? node.innerText : node.textContent || '';
    return text.replace(/[\u200B-\u200D\uFEFF]/g, '').trim();
  };
  async function prepareDraft(command) {
    const node = await waitForComposer();
    const text = draftText(node);
    if (!text) return;
    const stored = await chrome.storage.local.get(['studioDraftBackups']);
    const backups = Array.isArray(stored.studioDraftBackups) ? stored.studioDraftBackups : [];
    const previous = backups.at(-1);
    if (previous?.text === text && previous.chatUrl === location.href) return;
    await chrome.storage.local.set({ studioDraftBackups: [...backups, { text, chatUrl: location.href, jobId: command.id, createdAt: Date.now() }].slice(-10) });
  }
  async function restoreDraft() {
    if (currentJobId || isGenerating()) throw new Error('Hãy đợi tác vụ hoàn tất hoặc bấm Dừng trước khi khôi phục bản nháp.');
    const node = await waitForComposer();
    if (draftText(node)) throw new Error('Ô ChatGPT hiện có nội dung. Bản nháp vẫn được lưu, chưa ghi đè.');
    const stored = await chrome.storage.local.get(['studioDraftBackups']);
    const backup = (stored.studioDraftBackups || []).filter(item => item.chatUrl === location.href).at(-1);
    if (!backup) throw new Error('Hội thoại này chưa có bản nháp được lưu dự phòng.');
    await fillComposer(backup.text);
    return { ok: true };
  }
  const userTurnCount = () => document.querySelectorAll('[data-message-author-role="user"]').length;

  async function waitForSendButton(node) {
    for (let i = 0; i < 40; i += 1) {
      const button = sendButton(node);
      if (button && !button.disabled) return button;
      await sleep(250);
    }
    throw new Error('Nút gửi ChatGPT chưa sẵn sàng sau khi đã điền lệnh.');
  }

  async function submit(token) {
    const node = await waitForComposer();
    const beforeDraft = draftText(node);
    const beforeUserTurns = userTurnCount();
    const button = await waitForSendButton(node);
    if (token !== generation || cancelled) throw new Error('Đã dừng tác vụ.');
    button.focus();
    button.click();
    for (let i = 0; i < 24; i += 1) {
      if (token !== generation || cancelled) throw new Error('Đã dừng tác vụ.');
      if (isGenerating() || userTurnCount() > beforeUserTurns || draftText(node) !== beforeDraft) return;
      await sleep(250);
    }
    throw new Error('ChatGPT chưa gửi lệnh: nội dung vẫn nằm trong ô soạn thảo.');
  }

  async function run(command) {
    if (!command?.id || !command?.prompt) throw new Error('Lệnh từ Studio không hợp lệ.');
    if (currentJobId === command.id || finished.has(command.id)) return { ok: true, duplicate: true };
    if (currentJobId) throw new Error('ChatGPT đang xử lý một lệnh khác.');
    currentJobId = command.id;
    currentJobType = String(command.type || '');
    cancelled = false;
    const token = ++generation;
    replyContext = { ...command, before: VISReplyReader.snapshot(document) };
    try {
      if (isGenerating()) throw new Error('ChatGPT đang trả lời. Hãy bấm Dừng trước khi gửi phần tiếp theo.');
      if (command.type !== 'image_generation') await clearImageMode();
      await prepareDraft(command);
      if (token !== generation || cancelled) return;
      if (command.type === 'image_generation') {
        const beforeImages = imageUrls();
        // The job marker identifies this scene's prompt even when ChatGPT collapses it ("Show more").
        await fillComposer('[VIS_JOB_ID:' + command.id + ']' + String.fromCharCode(10) + command.prompt);
        await submit(token);
        await emit({ jobId: command.id, state: 'sent' });
        const payload = await waitForImage(beforeImages, token);
        if (token !== generation || cancelled) return;
        await emit(payload);
        finished.add(command.id);
        return;
      }
      // Studio refuses a scene split with more than 30 scenes; say so in the prompt (project 035, 2026-11-15).
      const sceneCap = job => job.type === 'part_analysis' && !/Tối đa 30 cảnh/.test(String(job.prompt || '')) ? 'Tối đa 30 cảnh (Studio không nhận quá 30): nếu nội dung dài, gộp các câu liền ý vào cùng một cảnh, giữ đủ lời đọc nguyên văn, không bỏ câu nào.' + String.fromCharCode(10) : '';
      const answerOnly = command.type === 'transcript_rewrite' ? 'Follow the output format specified in the prompt.' : 'Return only the requested JSON.';
      let text = '';
      // If ChatGPT draws a picture instead of answering, stop it and ask once more, more firmly, in the same chat
      // (the reader always takes the newest prompt carrying this job's marker).
      for (let attempt = 1; ; attempt += 1) {
        const warning = attempt === 1 ? '' : 'YOUR PREVIOUS ANSWER WRONGLY CREATED AN IMAGE. LẦN TRƯỚC BẠN ĐÃ TẠO ẢNH - SAI. Answer again with plain text only. ';
        const before = assistantText(currentJobType);
        await fillComposer('[VIS_JOB_ID:' + command.id + ']\nTEXT ANALYSIS ONLY. ' + warning + 'DO NOT GENERATE IMAGES, DO NOT CALL ANY IMAGE OR DRAWING TOOL; every "prompt" below is text to write, not a picture to make. KHÔNG TẠO ẢNH. ' + answerOnly + '\n' + sceneCap(command) + command.prompt);
        if (token !== generation || cancelled) return;
        if (activeImageMode()) throw new Error('Chế độ Tạo ảnh vẫn bật. Chưa gửi lệnh phân tích.');
        await submit(token);
        if (attempt === 1) await emit({ jobId: command.id, state: 'sent' });
        try { text = await waitForFinalAnswer(before, currentJobType, token); break; }
        catch (error) {
          if (error?.message !== IMAGE_INSTEAD) throw error;
          await stopAndSettle();
          if (attempt >= 2) throw new Error('ChatGPT tạo ảnh thay vì trả văn bản (2 lần). Phần này sẽ được giao lại.');
          if (token !== generation || cancelled) return;
          await clearImageMode();
        }
      }
      await emit({ jobId: command.id, state: 'completed', text });
      finished.add(command.id);
    } catch (error) {
      finished.add(command.id);
      if (token === generation && !cancelled) await emit({ jobId: command.id, state: 'error', text: error?.message || String(error) });
      throw error;
    } finally {
      if (token === generation) {
      currentJobId = '';
      currentJobType = '';
      cancelled = false;
      }
    }
  }

  // Masked account label + short hash (never the full e-mail) so AI MANAGER can see which Plus account each tab uses.
let accountInfo=null,accountAt=0;
async function chatAccountInfo(){
  if(Date.now()-accountAt<600000)return accountInfo;
  accountAt=Date.now();
  try{
    const data=await (await fetch('/api/auth/session',{credentials:'include'})).json();
    const email=String(data?.user?.email||'').trim().toLowerCase();
    const plan=String(data?.account?.planType||data?.account?.plan_type||data?.accountPlan||'').slice(0,40);
    const key=email?Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(email)))).slice(0,6).map(b=>b.toString(16).padStart(2,'0')).join(''):'';
    accountInfo={key,plan,label:email?email.replace(/^(.)[^@]*?(.)?@/,(m,a,b)=>a+'***'+(b||'')+'@'):''};
  }catch{}
  return accountInfo;
}
// ChatGPT's own "limit reached" notice, read only from what follows the latest user turn so an old notice
// from an earlier turn is not taken for a new one. Returns the short notice text or null.
// Two wordings seen: "You've hit the Plus plan limit ... resets in 5 hours" and the card "You're out of images /
// You're out of image creations for now. Try again at 10:46 PM." (the time is kept so the Manager knows when to go on).
const CHAT_LIMIT=/you['’]re out of image[\s\S]{0,200}?try again at \d{1,2}[:.]\d{2}\s*(?:[AP]\.?M\.?)?|you['’]re out of image[^\n]{0,160}|you['’]ve (?:hit|reached) the [^.\n]{0,60}limit[^\n]{0,160}|[^.\n]{0,80}limit resets in [^.\n]{0,40}|[^.\n]{0,60}usage (?:cap|limit)[^\n]{0,120}/i;
function chatLimitNotice(){
  try{
    const main=document.querySelector('main');const text=(main?.innerText||document.body?.innerText||'');
    const turns=document.querySelectorAll('[data-message-author-role="user"]');const last=turns[turns.length-1]?.innerText||'';
    const at=last?text.lastIndexOf(last):-1;const tail=at>=0?text.slice(at+last.length):text.slice(-2000);
    const hit=tail.match(CHAT_LIMIT);return hit?hit[0].replace(/\s+/g,' ').trim().slice(0,240):null;
  }catch{return null;}
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === 'MGR_FP') {
      const messages = document.querySelectorAll('[data-message-author-role="assistant"]');
      const last = messages[messages.length - 1];
      const body = (document.body?.innerText || '').slice(0, 5000);
      sendResponse({generating:isGenerating(),msgCount:messages.length,lastLen:(last?.innerText || '').length,captcha:/captcha|verify you are human/i.test(body),rateLimit:/too many requests|rate limit|try again later/i.test(body),login:!composer(),lastDomChange,jobId:currentJobId}); return;
    }
    if (message?.type === 'vis-conversation-size') {
      sendResponse({ chars: VISReplyReader.conversationChars(document), path: location.pathname, generating: isGenerating() || Boolean(currentJobId) });
      return;
    }
    if (message?.type === 'vis-ping') {
      (async()=>{
        const account=await chatAccountInfo();
        const st=await chrome.storage.local.get(['pairCode','activeJobId','activeCommand','conversationUrl','identityJobId']);
        let tabId=null;try {tabId=(await chrome.runtime.sendMessage({type:'vis-tab-id'}))?.chatTabId ?? null;}catch{}
        const url=/^\/c\/[^/]+$/.test(location.pathname)?location.origin+location.pathname:null;
        const turns=document.querySelectorAll('[data-message-author-role="user"]');
        const last=turns[turns.length-1];
        const marker=st.activeJobId && ((last && (last.innerText||'').includes('[VIS_JOB_ID:'+st.activeJobId+']')) || (document.querySelector('main')?.textContent||'').includes('[VIS_JOB_ID:'+st.activeJobId+']'));
        const imagePrompt=st.activeCommand?.type==='image_generation' && st.activeCommand?.id===st.activeJobId && typeof st.activeCommand.prompt==='string' && st.activeCommand.prompt.length>0 && last && (last.innerText||'').includes(st.activeCommand.prompt);
        const verified=currentJobId===st.activeJobId && !!currentJobId || Boolean((marker||imagePrompt) && st.identityJobId===st.activeJobId && st.conversationUrl===url);
        sendResponse({ready:Boolean(composer()),generating:isGenerating(),version:'0.5.25',conversationLabel:location.pathname,pairCode:st.pairCode||null,activeJobId:verified?st.activeJobId:null,chatTabId:tabId,conversationUrl:url,lastHeartbeatAt:Date.now(),account,limit:chatLimitNotice()});
      })().catch(()=>sendResponse({ready:Boolean(composer()),version:'0.5.25',conversationLabel:location.pathname,pairCode:null,activeJobId:null,chatTabId:null,conversationUrl:null,lastHeartbeatAt:null}));
      return true;
    }
    if (message?.type === 'vis-restore-draft') {
      restoreDraft().then(sendResponse).catch(error => sendResponse({ ok: false, error: error.message }));
      return true;
    }
    if (message?.type === 'vis-stop') {
      cancelled = true;
      for(const controller of downloads)controller.abort();
      generation += 1;
      if (currentJobId) finished.add(currentJobId);
      stopButton()?.click();
      currentJobId = '';
      currentJobType = '';
      sendResponse({ ok: true });
      return;
    }
    if (message?.type === 'vis-command') {
      if (currentJobId === message.command?.id || finished.has(message.command?.id)) { sendResponse({ ok: true, duplicate: true }); return; }
      if (currentJobId) {
        // The background no longer tracks the old job (finished, failed or abandoned before a reload) and
        // ChatGPT is idle: drop it instead of blocking every new command. A job ChatGPT still writes stays busy.
        if (!message.replaceStale || isGenerating()) { sendResponse({ ok: false, error: 'ChatGPT đang xử lý phần khác. Hãy bấm Dừng trước.' }); return; }
        finished.add(currentJobId); generation += 1; cancelled = false; currentJobId = ''; currentJobType = '';
      }
      run(message.command).catch(() => null);
      sendResponse({ ok: true });
      return;
    }
    if (message?.type === 'vis-capture-result') {
      const context = message.command?.id === message.jobId ? message.command : currentJobId === message.jobId ? replyContext : null;
      if (!context?.id) { sendResponse({ ok: false, error: 'Chưa nhận diện được tác vụ đang chờ.' }); return; }
      if (String(message.jobType || currentJobType || '') === 'image_generation') {
        if (isGenerating()) { sendResponse({ ok: false, error: 'ChatGPT vẫn đang tạo ảnh.' }); return; }
        imagePayload(context).then(payload => {
          if (!message.watchdog && currentJobId && (currentJobId === context.id || replyContext.prompt === context.prompt)) {finished.add(currentJobId);generation += 1;currentJobId='';currentJobType='';cancelled=false;}
          if(!message.watchdog)finished.add(context.id);sendResponse({ ok: true, payload });
        }).catch(error => sendResponse({ ok: false, error: error.message }));
        return true;
      }
      // Periodic (passive) checks must not read the page while ChatGPT is writing or while this tab's own
      // waiter runs the job: repeated full reads during streaming froze ChatGPT ("page isn't responding").
      if (message.passive && (isGenerating() || (currentJobId && currentJobId === context.id))) { sendResponse({ ok: false, busy: true }); return; }
      const result = VISReplyReader.readStreaming(document, { ...context, type: context.type || message.jobType || currentJobType });
      if (!result.text) { sendResponse({ ok: false, error: (result.reason === 'latest-user-mismatch' ? 'Tab ChatGPT đang mở không có lệnh của phần cần đồng bộ. Hãy mở đúng hội thoại đã trả lời phần này.' : result.reason === 'invalid-json' ? (isGenerating() ? 'ChatGPT vẫn đang trả lời phần này; JSON chưa hoàn tất. Đợi ChatGPT xong rồi đồng bộ lại.' : 'Đã tìm thấy phản hồi đúng phần nhưng JSON không hợp lệ: ' + (result.detail || 'không tìm thấy JSON') + '.') : 'Chưa đọc được câu trả lời sau lệnh của phần này. Giữ tab ChatGPT mở ở cuối phản hồi rồi bấm Đồng bộ lại.' ) + ' [' + VISReplyReader.diagnose(document, context) + ']' }); return; }
      // Capturing a valid reply ends the matching waiter without stopping ChatGPT.
      // Recovery may use a new job ID for the exact same original prompt.
      const complete = result.complete && !isGenerating();
      if (complete && currentJobId && (currentJobId === context.id || (replyContext.prompt && replyContext.prompt === context.prompt))) {
        finished.add(currentJobId);
        generation += 1;
        currentJobId = ''; currentJobType = ''; cancelled = false;
      }
      if (complete) finished.add(context.id);
      sendResponse({ ok: true, payload: { jobId: context.id, state: complete ? 'completed' : 'progress', text: result.text } });
    }
  });
})();


