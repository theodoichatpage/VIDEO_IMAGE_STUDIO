(()=>{
 if(globalThis.__VIS_BRIDGE_LOADED__)return;
 globalThis.__VIS_BRIDGE_LOADED__=true;
 const KEY='vis-command-v3';let busy=false,current=null,lastImage='',stable=0,partialText='',lastPlanReport=0,lastBridgeError='';
 const messageRole=e=>e.dataset?.messageAuthorRole||e.querySelector?.('[data-message-author-role]')?.dataset?.messageAuthorRole||((e.getAttribute?.('data-testid')||'').includes('conversation-turn')?(e.querySelector?.('[data-message-author-role]')?.getAttribute('data-message-author-role')||''):'');
 const messageNodes=()=>{
  const nodes=[...document.querySelectorAll('[data-message-author-role]')];
  for(const q of ['[data-testid^="conversation-turn-"]','[data-testid^="conversation-turn"]','article[data-turn]','main [data-message-author-role]'])nodes.push(...document.querySelectorAll(q));
  const unique=[...new Set(nodes.map(e=>e.closest?.('[data-testid^="conversation-turn-"],[data-testid^="conversation-turn"],article[data-turn]')||e))];
  return unique.sort((a,b)=>a.compareDocumentPosition?((a.compareDocumentPosition(b)&2)?1:(a.compareDocumentPosition(b)&4)?-1:0):0);
 };
 const markerMatches=(e,id)=>(e.textContent||'').replace(/[\u200B-\u200D\uFEFF]/g,'').includes('[VIS_JOB:'+id+']');
 const assistants=()=>messageNodes().filter(e=>messageRole(e)==='assistant');
 const extractAssistantText=e=>{
  if(!e)return '';
  const blocks=[...e.querySelectorAll?.('pre code, pre, code')||[]].map(x=>(x.innerText||x.textContent||'').trim()).filter(Boolean);
  const body=(e.innerText||e.textContent||'').trim();
  if(blocks.length){const json=blocks.find(x=>x.includes('\"job_id\"')||x.trim().startsWith('{'));if(json)return json;}
  return body;
 };
 const parseProtocolJson=(raw,c)=>{
  raw=String(raw||'').trim();if(!raw||!raw.includes(String(c.id)))return '';
  // Try fenced/plain response first, then every balanced-looking object start.
  const starts=[];for(let i=0;i<raw.length;i++)if(raw[i]==='{')starts.push(i);
  for(const st of starts){let depth=0,inStr=false,esc=false;
   for(let i=st;i<raw.length;i++){const ch=raw[i];if(inStr){if(esc)esc=false;else if(ch==='\\')esc=true;else if(ch==='"')inStr=false;continue}if(ch==='"'){inStr=true;continue}if(ch==='{')depth++;else if(ch==='}'&&--depth===0){const text=raw.slice(st,i+1);try{const d=JSON.parse(text);if(d.job_id===c.id&&d.run_id===c.pipeline_id&&d.stage===c.layout_stage&&Number(d.part)===c.pipeline_index+1&&Array.isArray(d.scenes))return text}catch(_){}break}}
  }return '';
 };
 const scanJsonProtocolReplies=c=>{
  // Do not depend on ChatGPT message-role selectors. Search rendered text containers
  // and accept only a complete JSON object carrying the exact protocol identity.
  const selectors='main pre code,main pre,main code,main [class*="markdown"],main article,main [data-testid^="conversation-turn"],main';
  const nodes=[...new Set(document.querySelectorAll(selectors))];
  for(let i=nodes.length-1;i>=0;i--){const raw=nodes[i].innerText||nodes[i].textContent||'';if(raw.length>1500000)continue;const hit=parseProtocolJson(raw,c);if(hit)return hit}
  return '';
 };
 const responseTextForJob=c=>scanJsonProtocolReplies(c);
 function expandPrompts(){for(const e of messageNodes()){if(messageRole(e)!=='user')continue;for(const b of e.querySelectorAll?.('button')||[]){if(/^(show more|xem thêm|hiển thị thêm)$/i.test((b.textContent||'').trim())&&!b.dataset.visExpanded){b.dataset.visExpanded='1';b.click()}}}}

 const visible=e=>!!e&&(!e.getBoundingClientRect||(()=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0})());
 const editor=()=>{
  for(const selector of ['#prompt-textarea','[contenteditable="true"][role="textbox"]','[contenteditable="true"][data-placeholder]','textarea[placeholder*="ChatGPT"]','textarea[placeholder*="Message"]','textarea[placeholder*="Nhắn"]','form [contenteditable="true"]','main [contenteditable="true"]','[contenteditable="plaintext-only"]','main textarea','form textarea','textarea[placeholder]']){
   const e=document.querySelector(selector);if(visible(e)&&!e.disabled&&e.getAttribute?.('aria-disabled')!=='true')return e;
  }
  return null;
 };
 const stopButton=()=>[...document.querySelectorAll('button[data-testid="stop-button"],button[data-testid="composer-stop-button"],button[aria-label="Stop streaming"],button[aria-label="Stop generating"],button[aria-label="Dừng tạo"],button[aria-label="Dừng phản hồi"]')].find(visible);
 const ready=()=>!!editor(); // A hidden verification iframe alone is not a sign-in wall.
 chrome.runtime.onMessage.addListener((m,_,reply)=>{if(m.type==='ping')reply({ready:ready(),version:'0.3.60'});if(m.type==='wake'){reply({ok:true});heartbeat();tick()}});
 async function bridge(type,data){const r=await chrome.runtime.sendMessage({type,data});if(r.error)throw Error(r.error);return r}
 async function report(phase,extra={}){return bridge('result',{id:current.id,phase,url:location.href,...extra})}
 function remember(){sessionStorage.setItem(KEY,JSON.stringify(current))}
 async function send(c){
  if(stopButton())return;
  const e=editor();if(!e)throw Error('Cần đăng nhập hoặc hoàn thành xác minh trong tab ChatGPT.');
  const existing=(e.textContent||e.value||'').trim();
  const softwareDraft=/\[VIS_JOB:[^\]]+\]/.test(existing);
  const sameDraft=existing.includes('[VIS_JOB:'+c.id+']');
  // The connected ChatGPT tab is owned by Studio while a queued command is dispatched.
  // ChatGPT can expose placeholder/decorative text through the composer DOM, so treating
  // every non-empty textContent as a user draft deadlocks the queue before insertion.
  // Always replace the connected composer with the queued Studio command.
  current={id:c.id,before:assistants().length,phase:'sending',sentAt:Date.now(),url:location.href,kind:c.kind,imageBaseline:c.download_only?null:allImages().map(i=>i.currentSrc||i.src),waitStartedAt:Date.now(),waitCycle:c.wait_cycle||0};remember();await report('sending');
  const text='[VIS_JOB:'+c.id+'] '+((c.kind==='plan'||c.kind==='analysis_text')?'Tác vụ PHÂN TÍCH VĂN BẢN. Không tạo ảnh. Chỉ xuất JSON.':'Mã theo dõi, KHÔNG đưa mã vào ảnh.')+'\n'+c.prompt;
  e.focus();
  // Drafts carrying VIS_JOB were inserted by Studio. Reuse the matching draft,
  // or replace a stale Studio draft left behind by a stopped/unconfirmed send.
  // Never replace ordinary text typed by the user.
  if(!sameDraft){if(e.tagName==='TEXTAREA'){const setter=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value')?.set;if(setter)setter.call(e,text);else e.value=text;e.dispatchEvent(new Event('input',{bubbles:true}))}else{const selection=window.getSelection();const range=document.createRange();range.selectNodeContents(e);selection.removeAllRanges();selection.addRange(range);let inserted=false;try{inserted=document.execCommand('insertText',false,text)}catch(_){}if(!inserted||!(e.textContent||'').includes(c.id)){e.textContent=text}e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:text}));e.dispatchEvent(new Event('change',{bubbles:true}))}}
  await new Promise(r=>setTimeout(r,700));
  if(!e.textContent?.includes(c.id)&&!e.value?.includes(c.id))throw Error('Không điền được ô prompt. Chưa gửi; kiểm tra thủ công.');
  let b=[...document.querySelectorAll('button[data-testid="send-button"],button[data-testid="composer-submit-button"],button[aria-label="Send prompt"],button[aria-label="Send message"],button[aria-label="Gửi lời nhắc"],button[aria-label="Gửi tin nhắn"],form button[type="submit"]')].find(b=>visible(b)&&!b.disabled);
  if(!b){for(let attempt=0;attempt<10&&!b;attempt++){await new Promise(resolve=>setTimeout(resolve,400));b=[...document.querySelectorAll('button[data-testid="send-button"],button[data-testid="composer-submit-button"],button[data-testid="composer-send-button"],button[aria-label="Send"],button[aria-label="Send message"],button[aria-label="Send prompt"],button[aria-label="Gửi"],form button[type="submit"]')].find(x=>visible(x)&&!x.disabled)}}
  if(!b){const candidates=[...document.querySelectorAll('button')];b=candidates.find(x=>visible(x)&&!x.disabled&&/^(send|send prompt|send message|gửi|gửi tin nhắn|gửi lời nhắc)$/i.test((x.getAttribute?.('aria-label')||x.getAttribute?.('title')||'').trim()))}
  if(!b||b.disabled)throw Error((c.kind==='analysis_text'||c.kind==='plan')?'Không tìm thấy nút Gửi của ChatGPT. Prompt phân tích vẫn ở ô nhập; bấm Gửi một lần rồi dùng Nhận phản hồi Phần hiện tại từ ChatGPT trong Studio.':'Không tìm thấy nút gửi hoạt động. Nội dung còn trong ô chat: bấm nút Gửi rồi tiếp tục tác vụ ảnh.');
  b.click();
  let submitted=false;
  for(let attempt=0;attempt<20;attempt++){
   const posted=messageNodes().some(node=>messageRole(node)==='user'&&markerMatches(node,c.id));
   if(posted){submitted=true;break}
   await new Promise(resolve=>setTimeout(resolve,500));
  }
  if(!submitted){
   // ChatGPT currently virtualizes/renames conversation turns often enough that a
   // successful click can produce a real answer while the user turn is invisible
   // to the extension. Text analysis is safe to keep observing because its reply
   // carries exact job_id/run_id/stage/part identity and cannot be mistaken for an
   // image result. Image jobs keep the stricter confirmation rule.
   if(c.kind==='analysis_text'||c.kind==='plan'){
    current.phase='sent';current.submissionUnverified=true;remember();await report('sent',{submission_unverified:true});return;
   }
   throw Object.assign(Error('Đã điền prompt nhưng chưa xác nhận gửi thành công. Kiểm tra nút Gửi trong ChatGPT; hàng đợi ảnh đã dừng để tránh gửi trùng.'),{sendUnconfirmed:true});
  }
  current.phase='sent';remember();await report('sent');
 }
 function allImages(){const found=[],visited=new Set();function walk(root){if(visited.has(root))return;visited.add(root);found.push(...root.querySelectorAll('img'));for(const e of root.querySelectorAll('*')){if(e.shadowRoot)walk(e.shadowRoot)}}walk(document);return [...new Set(found)].filter(i=>i.complete&&i.naturalWidth>=256&&i.naturalHeight>=256&&!i.closest?.('[data-vis-picker]'))}
 async function chooseImage(c,candidates=null){
  current={id:c.id,phase:'waiting',waitStartedAt:Date.now()};remember();if(!c.detectedReady)await report('waiting');
  const images=candidates||allImages();if(!images.length)throw Error('Không thấy ảnh đã tải trên tab ChatGPT này. Mở cuộc trò chuyện có ảnh và thử lại, hoặc dùng Nhập ảnh.');
  const box=document.createElement('div');box.setAttribute('data-vis-picker','true');box.style.cssText='position:fixed;inset:30px;z-index:2147483647;background:#fff;color:#173d50;border:2px solid #009ca6;border-radius:14px;padding:22px;overflow:auto;box-shadow:0 0 0 40px #0006;font:16px Arial';
  const title=document.createElement('h2');title.textContent='Chọn đúng ảnh để đưa về Studio';box.append(title);
  const hint=document.createElement('p');hint.textContent='Chỉ ảnh bạn bấm chọn được đồng bộ vào dòng đã chọn. Không tạo ảnh mới.';box.append(hint);
  const grid=document.createElement('div');grid.style.cssText='display:flex;flex-wrap:wrap;gap:14px';box.append(grid);
  const image=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{box.remove();reject(Error('Đã hết thời gian chọn ảnh. Bấm Chọn ảnh trên ChatGPT để thử lại.'))},120000);function finish(value){clearTimeout(timer);box.remove();if(value)resolve(value);else reject(Error('Đã hủy chọn ảnh.'))}
   for(const original of images){const b=document.createElement('button');b.style.cssText='padding:8px;background:#eef7fa;border:1px solid #cbd7df;border-radius:10px;cursor:pointer';const preview=document.createElement('img');preview.src=original.currentSrc||original.src;preview.style.cssText='width:260px;height:180px;object-fit:contain';b.append(preview);b.onclick=()=>finish(original);grid.append(b)}
   const cancel=document.createElement('button');cancel.textContent='Hủy';cancel.style.cssText='margin-top:20px;padding:10px 22px';cancel.onclick=()=>finish(null);box.append(cancel);document.body.append(box);
  });await saveCapturedImage(image);
 }
 async function saveCapturedImage(image){
  await report('image_ready');current.phase='saving';remember();await report('saving');let data;
  try{const canvas=document.createElement('canvas');canvas.width=image.naturalWidth;canvas.height=image.naturalHeight;canvas.getContext('2d').drawImage(image,0,0);data=canvas.toDataURL('image/png')}catch(e){const response=await fetch(image.currentSrc||image.src,{credentials:'include'});if(!response.ok)throw Error('Trình duyệt không cho đọc file ảnh này. Tải ảnh từ ChatGPT rồi dùng Nhập ảnh.');const blob=await response.blob();data=await new Promise((resolve,reject)=>{const f=new FileReader();f.onload=()=>resolve(f.result);f.onerror=reject;f.readAsDataURL(blob)})}
  await report('done',{image:data});sessionStorage.removeItem(KEY);current=null;lastImage='';stable=0;
 }
 // Pipeline replies carry exact identity; recovery must not depend on a visible
 // user marker (collapsed/virtualized turns or navigation during submission).
 function matchingPlanReply(c){
  if(!['plan','analysis_text'].includes(c.kind)||!c.pipeline_id)return null;
  for(const node of assistants().reverse()){
   const candidates=[...node.querySelectorAll('pre code'),node];
   for(const candidate of candidates){
    const raw=candidate.innerText||candidate.textContent||'';
    const start=raw.indexOf('{'),end=raw.lastIndexOf('}');
    if(start<0||end<start)continue;
    const text=raw.slice(start,end+1);
    try{const data=JSON.parse(text);
     if(data.job_id===c.id&&data.run_id===c.pipeline_id&&data.stage===c.layout_stage&&data.part===c.pipeline_index+1)return text;
    }catch(_){}
   }
  }
  return null;
 }
 async function capturePlanReply(c,text){
  if(!current||current.id!==c.id){current={id:c.id,kind:c.kind,phase:'waiting',waitStartedAt:Date.now(),waitCycle:c.wait_cycle||0};lastImage='';stable=0;remember()}
  if(current.phase==='sending'||current.phase==='sent'){current.phase='waiting';remember();await report('waiting')}
  if(text!==partialText||Date.now()-lastPlanReport>4000){await report('partial',{text});partialText=text;lastPlanReport=Date.now()}
  if(stopButton()){stable=0;return}
  if(lastImage!==text){lastImage=text;stable=0;return}
  if(++stable<3)return;
  await report('done',{text});sessionStorage.removeItem(KEY);current=null;lastImage='';stable=0;partialText='';
 }
 async function inspect(c){
  const matchedPlan=matchingPlanReply(c);if(matchedPlan){await capturePlanReply(c,matchedPlan);return;}
  if((c.kind==='plan'||c.kind==='analysis_text')&&c.recover_plan&&(!current||current.id!==c.id||current.waitCycle!==(c.wait_cycle||0))){
   current={id:c.id,phase:'waiting',waitStartedAt:Date.now(),waitCycle:c.wait_cycle||0,kind:c.kind};partialText='';lastImage='';stable=0;remember();
  }
  if(c.download_only&&c.status!=='queued')return;
  if(c.pick_image||c.status==='image_ready'){await chooseImage({...c,detectedReady:c.status==='image_ready'});return;}
  expandPrompts();
  if(c.receive_only&&(!current||current.id!==c.id)){
   const users=messageNodes().filter(e=>messageRole(e)==='user'||(e.textContent||'').includes('[VIS_JOB:'));
   const user=[...users].reverse().find(x=>(c.candidate_job_ids||[]).some(id=>markerMatches(x,id)));
   if(!user){current={id:c.id};throw Error('Không tìm thấy mã yêu cầu của ảnh này trên tab ChatGPT đã kết nối. Mở đúng cuộc trò chuyện hoặc dùng Nhập ảnh.');}
   const markerId=c.candidate_job_ids.find(id=>markerMatches(user,id));
   current={id:c.id,markerId,phase:'waiting',waitStartedAt:Date.now(),waitCycle:0,kind:'image'};lastImage='';stable=0;remember();await report('waiting');
  }
  if(!current||current.id!==c.id){
   const stored=sessionStorage.getItem(KEY);current=stored?JSON.parse(stored):null;
   if(!current||current.id!==c.id){
    if(c.status!=='queued'){
     const matched=messageNodes().filter(e=>messageRole(e)==='user'||(e.textContent||'').includes('[VIS_JOB:')).some(x=>markerMatches(x,c.id));
     if(matched){current={id:c.id,phase:'waiting',waitCycle:c.wait_cycle||0,waitStartedAt:Date.now(),url:location.href,kind:c.kind};remember();}
     else throw Error('Không tìm thấy yêu cầu đã gửi trong cuộc trò chuyện này. Mở đúng cuộc trò chuyện ChatGPT rồi Tiếp tục; không tự gửi lại.');
    }else{
    if(c.url&&location.href!==c.url){location.href=c.url;return}
    try{await send(c)}catch(e){if(current?.id!==c.id)current={id:c.id};throw e}return;
    }
   }
  }
  if(current.phase==='sending')throw Error('Gián đoạn lúc gửi. Kiểm tra yêu cầu trong ChatGPT, dùng nhập thủ công hoặc chủ động Tạo lại để tránh gửi trùng.');
  if(current.waitCycle!==(c.wait_cycle||0)||!current.waitStartedAt){current.waitCycle=c.wait_cycle||0;current.waitStartedAt=Date.now();remember()}
  // Text-analysis recovery is protocol-based: the JSON response itself contains
  // job_id. This works even when ChatGPT exposes 0 recognizable message nodes.
  if(c.kind==='analysis_text'||c.kind==='plan'){
   const direct=responseTextForJob(c);
   if(direct){
    if(direct!==partialText||Date.now()-lastPlanReport>4000){await report('partial',{text:direct});partialText=direct;lastPlanReport=Date.now()}
    if(!stopButton()){if(lastImage!==direct){lastImage=direct;stable=0;return}if(++stable>=2){await report('done',{text:direct});sessionStorage.removeItem(KEY);current=null;lastImage='';stable=0;return}}
   }
  }
  // Do not stop inspecting a completed image because an earlier waiting cycle expired.
  const users=messageNodes().filter(e=>messageRole(e)==='user'||(e.textContent||'').includes('[VIS_JOB:'));const user=users.find(x=>markerMatches(x,current.markerId||c.id));
  if(!user){
   if(c.kind==='image'&&Array.isArray(current.imageBaseline)&&!stopButton()){
    const fresh=allImages().filter(i=>!current.imageBaseline.includes(i.currentSrc||i.src));
    if(fresh.length){const fp=fresh.map(i=>i.currentSrc||i.src).join('|');if(lastImage!==fp){lastImage=fp;stable=0;return;}if(++stable<2)return;await report('image_ready');await chooseImage({...c,detectedReady:true},fresh);return;}
   }
   if(Date.now()-(current.sentAt||current.waitStartedAt)>120000)throw Error((c.kind==='analysis_text'||c.kind==='plan')?'Chưa đọc được JSON của Phần hiện tại sau 2 phút. Giữ đúng tab ChatGPT có kết quả và bấm Nhận phản hồi Phần hiện tại từ ChatGPT; không gửi lại prompt.':'Chưa tìm thấy mã yêu cầu ảnh trên tab này sau 2 phút. Mở đúng cuộc trò chuyện rồi tiếp tục.');return;}
  if(current.phase==='sent'){current.phase='waiting';remember();await report('waiting')}
  // Only a response following this marked request and before any later user request.
  const messages=messageNodes();const idx=messages.indexOf(user);const following=[];
  for(const m of messages.slice(idx+1)){if(messageRole(m)==='user')break;if(messageRole(m)==='assistant'||m.querySelector?.('img'))following.push(m)}
  if(!following.length){if((c.kind==='plan'||c.kind==='analysis_text')&&Date.now()-lastPlanReport>4000){await report('partial',{text:''});lastPlanReport=Date.now()}return;}
  const response=following.at(-1);const text=extractAssistantText(response);
  if(/reached.{0,40}limit|image generation limit|đạt.{0,30}giới hạn|unable to generate|không thể tạo ảnh/i.test(text)&&!response.querySelector('img'))throw Error('ChatGPT báo giới hạn hoặc chưa tạo được ảnh. Xử lý trong tab rồi tiếp tục.');
  if(c.kind==='plan'||c.kind==='analysis_text'){
   if(/creating image|đang tạo (?:hình )?ảnh/i.test(text)||[...response.querySelectorAll('img')].some(i=>i.complete&&i.naturalWidth>=512&&i.naturalHeight>=256))throw Error('ChatGPT đang tạo ảnh thay vì trả dữ liệu văn bản. Phân tích đã dừng; các phần đã lưu được giữ. Dừng tạo ảnh trong ChatGPT rồi dùng chat văn bản để tiếp tục.');
   if(text!==partialText||Date.now()-lastPlanReport>4000){await report('partial',{text});partialText=text;lastPlanReport=Date.now()}
   if(stopButton())return;
   if(!text.trim())return;
   if(lastImage!==text){lastImage=text;stable=0;return}if(++stable<3)return;
   await report('done',{text});sessionStorage.removeItem(KEY);current=null;lastImage='';return;
  }
  if(stopButton())return;
  const images=[...response.querySelectorAll('img')].filter(i=>i.complete&&i.naturalWidth>=512&&i.naturalHeight>=256);
  // ChatGPT sometimes mounts generated media in a sibling assistant message.
  if(!images.length){for(const m of following){for(const i of m.querySelectorAll('img')){if(i.complete&&i.naturalWidth>=512&&i.naturalHeight>=256)images.push(i)}}}
  if(!images.length)return;
  const image=images.at(-1);const fingerprint=image.currentSrc+'|'+image.naturalWidth+'|'+image.naturalHeight;
  if(lastImage!==fingerprint){lastImage=fingerprint;stable=0;return}if(++stable<2)return;
  await saveCapturedImage(image);
 }
 async function tick(){if(busy)return;busy=true;try{
  const r=await bridge('poll',{ready:ready(),generating:!!stopButton(),url:location.href});if(r.inactive)return;
  if(r.paused||!r.command){if(current){sessionStorage.removeItem(KEY);current=null;lastImage='';stable=0;}return;}
  if(!ready())return;
  await inspect(r.command);
 }catch(e){lastBridgeError=e.message;console.error('Video Image Studio:',e.message);if(current){try{await report(e.sendUnconfirmed?'send_unconfirmed':'error',{error:e.message})}catch(_){} sessionStorage.removeItem(KEY);current=null;lastImage='';stable=0;}}finally{busy=false}}
 let heartbeatBusy=false;
 async function heartbeat(){if(heartbeatBusy)return;heartbeatBusy=true;try{await bridge('heartbeat',{ready:ready(),generating:!!stopButton(),url:location.href,diagnostics:{version:'0.3.60',busy,phase:current?.phase||'',messages:messageNodes().length,assistants:assistants().length,error:lastBridgeError}})}catch(_){}finally{heartbeatBusy=false}}
 setInterval(heartbeat,2000);heartbeat();
 setInterval(tick,2000);tick();
})();
