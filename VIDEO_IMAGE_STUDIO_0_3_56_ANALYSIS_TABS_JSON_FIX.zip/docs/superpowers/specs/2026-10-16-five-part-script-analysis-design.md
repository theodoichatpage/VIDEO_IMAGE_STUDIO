# Thiết kế phân tích kịch bản 5 phần có duyệt

## Mục tiêu
Thay pipeline 0.3.50 đang tự cắt kịch bản theo độ dài bằng pipeline để ChatGPT đọc toàn bộ kịch bản, chia mạch kể thành đúng 5 phần logic, chỉ phân tích một phần tại một thời điểm thành các cảnh có nghĩa, rồi dừng chờ người dùng duyệt trước khi sang phần kế tiếp. Giai đoạn này tuyệt đối không tạo ảnh và không quyết định góc máy/cỡ cảnh/bố cục.

## Luồng người dùng
1. Người dùng nhập toàn bộ kịch bản và bấm **Tự chia cảnh và phân tích**.
2. Studio gửi toàn bộ kịch bản một lần cho ChatGPT, yêu cầu trả **bản đồ 5 phần** và **phân tích chi tiết Phần 1**.
3. Mỗi cảnh của phần hiện tại gồm: `scene_no`, `title`, `source`, `focus`, `story_role`. `source` phải là nguyên văn liên tiếp từ kịch bản.
4. Studio lưu kết quả và chuyển trạng thái thành **Phần 1/5 · Chờ duyệt**. Không tự gửi phần 2.
5. Người dùng có thể chỉnh/duyệt. Nút **Duyệt · Phân tích phần 2** gửi yêu cầu tiếp theo trong cùng cuộc hội thoại, kèm dữ liệu trạng thái cần thiết để ChatGPT phân tích phần kế tiếp.
6. Lặp lại đến phần 5. Số cảnh do nội dung quyết định, không ép 49 cảnh.
7. Khi 5/5 phần đã duyệt, Studio ghép danh sách cảnh theo thứ tự và mở giai đoạn **Phương án hình ảnh** riêng.
8. Chỉ ở giai đoạn hình ảnh mới yêu cầu `subject`, `action`, `setting`, `shot`, `angle`, `composition`, `difference`; sau khi duyệt phương án mới cho phép tạo ảnh.

## Quy tắc bảo toàn nội dung
- Không chia bằng số ký tự, số câu hoặc target scene count.
- Mỗi `source` là nguyên văn, không tóm tắt, không viết lại.
- Các `source` của 5 phần khi ghép theo thứ tự phải khôi phục toàn bộ kịch bản (cho phép khác khoảng trắng thuần túy).
- Không bỏ, lặp hoặc đảo thứ tự nội dung.
- Nếu phản hồi không đạt kiểm tra bảo toàn, Studio giữ checkpoint cuối cùng và yêu cầu nhận lại kết quả, không tự tiến bước.
- Các tuyên bố/số liệu trong kịch bản được giữ như nội dung nguồn; AI không tự nâng thành sự thật đã xác minh.

## Trạng thái và checkpoint
Pipeline lưu: `run_id`, snapshot kịch bản, bản đồ 5 phần, `current_part`, cảnh từng phần, trạng thái duyệt từng phần, conversation URL và lỗi cuối. Trạng thái chính: `analyzing_part`, `awaiting_approval`, `analysis_complete`, `visual_planning`, `visual_ready`.

Đóng/mở Studio không làm mất tiến độ. Khi `awaiting_approval`, hàng đợi không được tự gửi lệnh mới. Nút gửi lại chỉ nhận lại phản hồi của tác vụ đang chờ, không khởi động lại pipeline từ đầu.

## Giao thức ChatGPT
Prompt phân tích phải nói rõ: chỉ trả JSON văn bản, không gọi công cụ, không tạo ảnh, không xác định góc máy/cỡ cảnh/bố cục ở giai đoạn phân tích. Phản hồi đầu gồm `job_id`, `run_id`, `stage`, `part`, `parts` (5 phần) và `scenes` của phần 1. Phản hồi phần 2–5 giữ nguyên `parts` đã chốt và chỉ trả `scenes` cho phần được yêu cầu.

Studio không dựa vào văn bản hiển thị tự do để đoán trạng thái; chỉ nhận phản hồi có đúng `job_id/run_id/stage/part`.

## UI
Khối Phân tích hiển thị bản đồ 5 phần, phần đang xem, số cảnh, trạng thái và danh sách cảnh. Khi chờ duyệt có hai hành động chính: **Duyệt · Phân tích phần N+1** và **Phân tích lại phần N**. Sau phần 5 là **Duyệt · Hoàn tất phân tích**.

Khối Tạo ảnh bị khóa trong khi chưa `analysis_complete`/chưa có phương án hình ảnh đã duyệt. Không một command phân tích nào được đánh dấu là image job.

## Tương thích dữ liệu cũ
Checkpoint kiểu `split/plan/review`, `unit_ids/groups` của 0.3.49–0.3.50 không được tiếp tục như pipeline mới. Dự án cũ vẫn giữ kịch bản/thiết lập, nhưng khi bắt đầu phân tích mới sẽ tạo state v2 sạch. Chức năng Tạo ảnh, Tách ảnh và Dựng video hiện có được giữ nguyên ngoài cổng điều kiện mới.

## Tiêu chí chấp nhận
- Kịch bản mẫu dài không bị cắt theo độ dài và không mất chữ.
- Lượt đầu chỉ trả bản đồ 5 phần + cảnh Phần 1, rồi dừng.
- Không có image-generation command trong toàn bộ 5 phần phân tích.
- Không thể tự chạy từ phần 1 sang phần 2 nếu chưa có thao tác duyệt.
- Ghép `source` của toàn bộ cảnh sau 5 phần khôi phục đủ kịch bản.
- Sau khi hoàn tất 5 phần, dữ liệu cảnh có thể chuyển sang pipeline lập phương án hình ảnh riêng.
