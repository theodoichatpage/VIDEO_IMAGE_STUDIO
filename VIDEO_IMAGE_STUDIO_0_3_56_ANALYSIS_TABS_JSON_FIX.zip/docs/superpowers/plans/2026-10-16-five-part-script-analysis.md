# Five-Part Script Analysis Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the 0.3.50 character-based script splitter with a checkpointed five-part semantic analysis flow that stops for user approval after every part and never creates images during analysis.

**Architecture:** `analysis_pipeline.py` becomes a state machine with `analyzing_part`, `awaiting_approval`, `analysis_complete`, `visual_planning`, and `visual_ready`. The first ChatGPT request receives the complete script and returns the fixed five-part map plus scenes for part 1; later requests analyze only the approved next part in the same conversation. `server.py` exposes explicit approve/reanalyze actions, while `index.html` renders checkpoints and blocks visual/image work until text analysis is complete.

**Tech Stack:** Python/Flask backend, vanilla HTML/JavaScript UI, Chromium/Edge extension bridge, existing unittest/Node test harnesses.

**Spec:** `docs/superpowers/specs/2026-10-16-five-part-script-analysis-design.md`

## Global Constraints

- Preserve the full original script; scene `source` values must be verbatim and ordered.
- Exactly five logical parts; scene count is content-driven and is not capped at 49.
- Text-analysis prompts must explicitly prohibit image generation and camera/shot/composition planning.
- No automatic transition from one part to the next; user approval is required.
- Existing Create Image, Split Image, and Video Builder features remain intact apart from the new readiness gate.
- Old `split/plan/review` and `groups/unit_ids` checkpoints are not resumed as the new pipeline.

## Review Focus

- Very long scripts: first request must carry the complete script without local semantic splitting and preserve all text.
- ChatGPT returns paraphrased/missing/duplicated `source`: reject response and keep last checkpoint.
- Restart while awaiting approval: reopen at the same part without queueing the next prompt.
- User edits script after part 1: reject approve/resume because snapshot signature changed.
- Analysis response accidentally contains visual fields or triggers an image command: analysis command remains text-only and visual/image routes stay blocked.

---

### Task 1: Five-part pipeline state and response validation

**Files:**
- Modify: `analysis_pipeline.py`
- Test: `test_five_part_analysis.py`

**Interfaces:**
- Produces: `start(p, snapshot)`, `queue_next(p, first=False)`, `accept(p, c, text)`, `approve_part(p)`, `reanalyze_part(p)`, `describe(state)` using the new state model.
- State keys: `id`, `snapshot`, `parts`, `current_part`, `part_scenes`, `approved_parts`, `stage`, `status`, `saved`, `last_error`.

- [ ] **Step 1: Write failing tests** for first-request full-script payload, exactly five-part response, verbatim scene sources, no visual fields, and pause at `awaiting_approval` after part 1.
- [ ] **Step 2: Run** `python -m unittest -v test_five_part_analysis.py` and confirm failures are caused by the old local-segment pipeline.
- [ ] **Step 3: Implement the minimal five-part state machine** in `analysis_pipeline.py`; remove `local_segments()` from new script analysis and generate text-only schemas/prompts.
- [ ] **Step 4: Add validation** that part 1 returns exactly five map entries, later parts keep the same map, scene sources are ordered verbatim spans, and completed parts reconstruct the original script modulo whitespace.
- [ ] **Step 5: Run** `python -m unittest -v test_five_part_analysis.py` and confirm PASS.

### Task 2: Approval/reanalysis server API and restart safety

**Files:**
- Modify: `server.py`
- Test: `test_five_part_routes.py`

**Interfaces:**
- Consumes: new pipeline methods from Task 1.
- Produces: `POST /api/analysis-approve-part`, `POST /api/analysis-reanalyze-part`; updates `/api/layout-analysis`, `/api/analysis-resume`, recovery/import handling for the new stages.

- [ ] **Step 1: Write failing route tests** proving no next command is queued before approval, approval queues exactly one next-part command, part 5 approval completes text analysis, and stale snapshots are rejected.
- [ ] **Step 2: Run** `python -m unittest -v test_five_part_routes.py` and confirm expected failures.
- [ ] **Step 3: Implement approval/reanalysis routes and state transitions**; mark old checkpoint versions abandoned when a new analysis starts.
- [ ] **Step 4: Update bridge/recovery status handling** so reopening at `awaiting_approval` does not auto-queue work.
- [ ] **Step 5: Run** `python -m unittest -v test_five_part_routes.py` and confirm PASS.

### Task 3: Convert approved text scenes into Studio drafts without visual planning

**Files:**
- Modify: `analysis_pipeline.py`
- Modify: `server.py`
- Test: `test_five_part_completion.py`

**Interfaces:**
- Consumes: approved `part_scenes` from Tasks 1–2.
- Produces: ordered `manual_drafts`/analysis scene records after part 5; visual planning remains a separate explicit action.

- [ ] **Step 1: Write failing completion tests** for arbitrary scene counts, stable ordering, exact source preservation, and no `scene_layouts`/image commands at text-analysis completion.
- [ ] **Step 2: Run** `python -m unittest -v test_five_part_completion.py` and confirm failures.
- [ ] **Step 3: Implement completion projection** from five approved parts into Studio scene drafts and `analysis_complete` state.
- [ ] **Step 4: Add guards** so image creation cannot run from text-analysis data alone; existing visual-plan approval remains required.
- [ ] **Step 5: Run** `python -m unittest -v test_five_part_completion.py` and confirm PASS.

### Task 4: Five-part review UI

**Files:**
- Modify: `index.html`
- Test: `test_five_part_ui.cjs`

**Interfaces:**
- Consumes: `analysis_pipeline.parts`, `current_part`, `part_scenes`, `approved_parts`, `stage` from `/api/state`.
- Produces: visible five-part map, current-part scene cards, `Duyệt · Phân tích phần N+1`, `Phân tích lại phần N`, and final `Duyệt · Hoàn tất phân tích` controls.

- [ ] **Step 1: Write failing DOM/source tests** for the five-part labels, approval controls, removal of “chia văn bản theo nhóm” copy, and disabled image controls before visual readiness.
- [ ] **Step 2: Run** `node test_five_part_ui.cjs` and confirm failures.
- [ ] **Step 3: Implement UI rendering and actions** in `index.html`, keeping existing tabs/features intact.
- [ ] **Step 4: Update telemetry/help text** to show `Phần N/5 · Chờ duyệt` and scene counts instead of local segments/groups.
- [ ] **Step 5: Run** `node test_five_part_ui.cjs` and confirm PASS.

### Task 5: Versioning, regression verification, and package

**Files:**
- Modify: `server.py`
- Modify: `index.html`
- Modify: `extension/manifest.json`
- Create: `CAP_NHAT_0_3_51.txt`
- Verify: existing relevant Python/Node tests plus Tasks 1–4 tests.

**Interfaces:**
- Produces: version `0.3.51` package with matching Studio and extension versions.

- [ ] **Step 1: Add failing/version assertions** where existing tests enforce the app/extension version.
- [ ] **Step 2: Set version to `0.3.51`** consistently and document the new five-part workflow.
- [ ] **Step 3: Run focused regression suite:** `python -m unittest -v test_five_part_analysis.py test_five_part_routes.py test_five_part_completion.py test_analysis_recovery.py test_blockers.py` and `node test_five_part_ui.cjs && node test_extension.cjs`.
- [ ] **Step 4: Run syntax checks:** `python -m py_compile analysis_pipeline.py server.py scene_analysis.py` and `node --check extension/content.js`.
- [ ] **Step 5: Package the verified project** as `VIDEO_IMAGE_STUDIO_0_3_51_FIVE_PART_ANALYSIS.zip` without caches/runtime state.
