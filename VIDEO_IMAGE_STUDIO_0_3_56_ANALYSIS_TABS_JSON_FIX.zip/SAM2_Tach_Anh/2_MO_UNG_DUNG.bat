@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
 echo Hay chay 1_CAI_DAT.bat truoc.
 pause
 exit /b 1
)
.venv\Scripts\python.exe app.py
pause
