import io,os,threading,uuid,traceback
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from PIL import Image,ImageOps
from flask import Flask,request,jsonify,send_file
from layers import partition,export_layers
ROOT=Path(__file__).resolve().parent
app=Flask(__name__);app.config['MAX_CONTENT_LENGTH']=30*1024*1024
jobs={};pool=ThreadPoolExecutor(max_workers=1);model=None

def run_job(jid,rgb,detail,mode="semantic"):
    global model
    j=jobs[jid]
    try:
        names={}
        if mode=='semantic':
            from semantic import detect
            labels,names=detect(rgb,lambda text:j.update(status='running',message=text))
        else:
            import torch
            from sam2.build_sam import build_sam2
            from sam2.automatic_mask_generator import SAM2AutomaticMaskGenerator
            device='cuda' if torch.cuda.is_available() else 'cpu'
            j.update(status='running',message='Đang nạp SAM 2.1 ('+device+'). Lần đầu có thể lâu.')
            if model is None:model=build_sam2('configs/sam2.1/sam2.1_hiera_t.yaml',str(ROOT/'models/sam2.1_hiera_tiny.pt'),device=device,apply_postprocessing=False)
            generator=SAM2AutomaticMaskGenerator(model,points_per_side=detail,points_per_batch=16 if device=='cuda' else 8,pred_iou_thresh=.75,stability_score_thresh=.90,crop_n_layers=1 if detail>=48 else 0,min_mask_region_area=0)
            j['message']='AI đang tìm các vùng vật thể. Không đóng cửa sổ chạy phần mềm.'
            with torch.inference_mode(): masks=generator.generate(rgb)
            j['message']='Đang xuất các lớp và kiểm tra ghép lại.'
            labels=partition(rgb,masks)
        data,info,exact=export_layers(rgb,labels,names)
        for item in info:item['title']=names.get(item['id'],'Nền còn lại' if item['id']==0 else 'Vùng '+str(item['id']))
        out=ROOT/'outputs'/jid;out.mkdir(parents=True,exist_ok=True)
        (out/'cac_lop.zip').write_bytes(data)
        # Output our own trusted archive names only.
        import zipfile
        with zipfile.ZipFile(io.BytesIO(data)) as z:z.extractall(out)
        j.update(status='done',message='Hoàn tất',layers=info,exact=exact,width=rgb.shape[1],height=rgb.shape[0])
    except Exception as e:
        traceback.print_exc();j.update(status='error',message=str(e)+' — xem cửa sổ chạy để biết chi tiết.')

@app.get('/')
def index():return send_file(ROOT/'index.html')
@app.post('/api/segment')
def segment():
    if any(j['status'] in ('queued','running') for j in jobs.values()):return jsonify(error='Đang xử lý một ảnh. Vui lòng đợi.'),409
    f=request.files.get('image')
    if not f:return jsonify(error='Chọn ảnh trước.'),400
    try:
        image=ImageOps.exif_transpose(Image.open(f.stream));image.load()
        if image.width*image.height>16000000:return jsonify(error='Ảnh quá lớn. Hãy dùng ảnh dưới 16 megapixel.'),400
        if image.mode=='RGBA':
            bg=Image.new('RGB',image.size,'white');bg.paste(image,mask=image.getchannel('A'));image=bg
        rgb=np.asarray(image.convert('RGB'));detail=int(request.form.get('detail','32'))
        if detail not in (16,32,48):return jsonify(error='Chế độ không hợp lệ.'),400
    except Exception:return jsonify(error='Không đọc được ảnh.'),400
    jid=uuid.uuid4().hex;jobs[jid]={'status':'queued','message':'Đang chờ xử lý'};pool.submit(run_job,jid,rgb,detail,'regions' if request.form.get('mode')=='regions' else 'semantic');return jsonify(id=jid)
@app.get('/api/job/<jid>')
def job(jid):return jsonify(jobs[jid]) if jid in jobs else (jsonify(error='Không tìm thấy'),404)
@app.get('/output/<jid>/<name>')
def output(jid,name):
    if jid not in jobs or jobs[jid]['status']!='done':return 'Not found',404
    allowed={'cac_lop.zip','ghep_lai.png','anh_goc.png','vi_tri.json'}|{l['file'] for l in jobs[jid]['layers']}
    if name not in allowed:return 'Not found',404
    return send_file(ROOT/'outputs'/jid/name,as_attachment=name.endswith('.zip'))
if __name__=='__main__':
    import webbrowser
    threading.Timer(2,lambda:webbrowser.open('http://127.0.0.1:7860')).start()
    app.run(host='127.0.0.1',port=7860,debug=False,threaded=True)
