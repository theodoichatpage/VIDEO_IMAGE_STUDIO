import numpy as np
from PIL import Image,ImageDraw

def semantic_partition(rgb,people,texts):
 h,w=rgb.shape[:2];labels=np.zeros((h,w),np.int32);names={};idx=0
 # Whole detected people own their mask before text is considered.
 for mask in people:
  mask=np.asarray(mask,dtype=bool)
  if mask.shape!=(h,w):raise ValueError('Mask size mismatch')
  keep=mask&(labels==0)
  if not keep.any():continue
  idx+=1;labels[keep]=idx;names[idx]='Người '+str(len(names)+1)
 for n,result in enumerate(texts,1):
  box=result[0];text=result[1]
  canvas=Image.new('L',(w,h));ImageDraw.Draw(canvas).polygon([tuple(map(float,p)) for p in box],fill=255)
  area=np.asarray(canvas)>0
  # Keep the entire OCR paragraph as one layer, including its original backdrop.
  # This preserves every glyph and accent without inventing/rewriting text.
  keep=area&(labels==0)
  if not keep.any():continue
  idx+=1;labels[keep]=idx;names[idx]='Cụm chữ '+str(n)+': '+str(text)
 return labels,names

_detector=None
_reader=None
def detect(rgb,message):
 global _detector,_reader
 import torch
 from torchvision.models.detection import maskrcnn_resnet50_fpn,MaskRCNN_ResNet50_FPN_Weights
 import easyocr
 device='cuda' if torch.cuda.is_available() else 'cpu'
 message('Đang nạp mô hình nhận diện nguyên người…')
 if _detector is None:_detector=maskrcnn_resnet50_fpn(weights=MaskRCNN_ResNet50_FPN_Weights.DEFAULT).eval().to(device)
 tensor=torch.from_numpy(rgb.copy()).permute(2,0,1).float().div(255).to(device)
 with torch.inference_mode():result=_detector([tensor])[0]
 people=[mask[0].detach().cpu().numpy()>=.5 for mask,label,score in zip(result['masks'],result['labels'],result['scores']) if int(label)==1 and float(score)>=.5]
 message('Đang nhận diện và gom nguyên cụm chữ…')
 if _reader is None:_reader=easyocr.Reader(['vi','en'],gpu=device=='cuda')
 texts=_reader.readtext(rgb,paragraph=True,detail=1)
 return semantic_partition(rgb,people,texts)
