import sys,subprocess,json,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent
status=ROOT/'studio_status.json'
def update(state,message):status.write_text(json.dumps({'status':state,'message':message},ensure_ascii=False),encoding='utf8')
try:
 python=ROOT/'.venv/Scripts/python.exe'
 if not python.exists():
  update('installing','Đang tạo môi trường SAM2…');subprocess.run([sys.executable,'-m','venv',str(ROOT/'.venv')],check=True)
 if not (ROOT/'studio_ready_semantic_v1.txt').exists():
  update('installing','Đang cài SAM2 và tải mô hình. Giữ cửa sổ cài đặt mở.');subprocess.run([str(python),str(ROOT/'install.py')],cwd=ROOT,check=True);(ROOT/'studio_ready_semantic_v1.txt').write_text('ready')
 update('starting','Đang khởi động SAM2…')
 subprocess.run([str(python),str(ROOT/'app.py')],cwd=ROOT,check=True)
 update('stopped','SAM2 đã đóng. Bấm Khởi động SAM2 để mở lại.')
except Exception as e:
 traceback.print_exc();update('error','Cài hoặc khởi động SAM2 chưa thành công: '+str(e));input('Nhan Enter de dong...')
