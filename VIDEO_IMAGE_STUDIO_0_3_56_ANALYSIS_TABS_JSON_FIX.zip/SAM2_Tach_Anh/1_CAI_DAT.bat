@echo off
cd /d "%~dp0"
py -3.11 --version >nul 2>&1
if errorlevel 1 (
 echo Can cai Python 3.11 truoc. Mo trang Python de tai ban Windows installer 64-bit.
 start https://www.python.org/downloads/release/python-3119/
 pause
 exit /b 1
)
if not exist .venv\Scripts\python.exe py -3.11 -m venv .venv
if errorlevel 1 goto failed
.venv\Scripts\python.exe install.py
if errorlevel 1 goto failed
 echo Cai dat xong. Mo 2_MO_UNG_DUNG.bat
 pause
 exit /b 0
:failed
 echo Cai dat chua thanh cong. Chup cua so nay de kiem tra.
 pause
 exit /b 1
