import io,json,zipfile
import numpy as np
from PIL import Image

def partition(rgb, masks, min_pixels=10):
    h,w=rgb.shape[:2]; labels=np.zeros((h,w),np.int32); entries=[]
    # Small masks first: finer parts take ownership; no pixel belongs to two layers.
    masks=sorted(masks,key=lambda m:int(np.count_nonzero(m['segmentation'])))
    for m in masks:
        mask=np.asarray(m['segmentation'],dtype=bool)
        if mask.shape!=(h,w): raise ValueError('Mask size mismatch')
        keep=mask & (labels==0)
        if np.count_nonzero(keep)<min_pixels: continue
        idx=len(entries)+1;labels[keep]=idx;entries.append(idx)
    return labels

def export_layers(rgb,labels,names=None):
    h,w=rgb.shape[:2];buf=io.BytesIO(); info=[];reconstructed=np.zeros_like(rgb)
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
        for idx in np.unique(labels):
            mask=labels==idx
            ys,xs=np.where(mask);x,y=int(xs.min()),int(ys.min());right,bottom=int(xs.max()+1),int(ys.max()+1)
            rgba=np.zeros((bottom-y,right-x,4),np.uint8);local=mask[y:bottom,x:right]
            rgba[:,:,:3]=rgb[y:bottom,x:right];rgba[:,:,3]=local.astype(np.uint8)*255
            # Transparent RGB values zeroed; source pixels in visible regions untouched.
            rgba[~local]=0
            name='nen_con_lai.png' if idx==0 else f'phan_{idx:03d}.png'
            b=io.BytesIO();Image.fromarray(rgba).save(b,format='PNG');z.writestr(name,b.getvalue())
            reconstructed[mask]=rgb[mask]
            info.append(dict(id=int(idx),title=(names or {}).get(int(idx),'Nền còn lại' if idx==0 else 'Vùng '+str(idx)),file=name,x=x,y=y,width=right-x,height=bottom-y,pixels=int(mask.sum())))
        exact=bool(np.array_equal(reconstructed,rgb))
        for name,arr in [('anh_goc.png',rgb),('ghep_lai.png',reconstructed)]:
            b=io.BytesIO();Image.fromarray(arr).save(b,format='PNG');z.writestr(name,b.getvalue())
        z.writestr('vi_tri.json',json.dumps(dict(width=w,height=h,exact_reconstruction=exact,layers=info),ensure_ascii=False,indent=2))
    return buf.getvalue(),info,exact
